package com.workercompras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkercomprasApplicationTests {

	@Test
	void contextLoads() {
	}

}
