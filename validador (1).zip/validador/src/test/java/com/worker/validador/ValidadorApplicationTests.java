package com.worker.validador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
